public class Postgraduate extends Degree{
    public void getDegree(){
       System.out.println("I am Postgraduate ");
       
       
       
       t
    }
}