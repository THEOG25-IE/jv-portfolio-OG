public class Degree{
    
    public void getDegree(){
        System.out.println("i got a Degree");
        
    }
}