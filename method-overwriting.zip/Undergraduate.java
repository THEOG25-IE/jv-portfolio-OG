public class Undergraduate extends Degree{
    public void getDegree(){
     System.out.println("I am Undergraduate ");
    }
}