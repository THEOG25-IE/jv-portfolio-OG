/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		int num1=17;
		if(num1<0)
		{	System.out.println("the number is negative ");
			num1=num1*-1;
				System.out.println(+num1);
			}else{
			num1=num1*-1;    
			    	System.out.println(+num1);}
	}
}
