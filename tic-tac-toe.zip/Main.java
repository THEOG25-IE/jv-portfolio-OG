/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
	char arr [][]=new char[3][3];
		Scanner scanner= new Scanner(System.in);
		char turn= 'X';
		for(int i=0;i< arr.length;i++){
		for(int j=0;j<arr.length;j++){
                   arr[i][j]='-';
		     
		}
		}
while(true){
    for(int i=0;i< arr.length;i++){
		for(int j=0;j<arr.length;j++){
                   System.out.print(arr[i][j]+" ");
		     
		}
		System.out.println ("");
		} System.out.println(turn+"'s turn");
		
		System.out.println("enter the row number beetween 1 and 3");
		int row= scanner.nextInt();
		System.out.println("enter the colum number beetween 1 and 3");
		int colum =scanner.nextInt();
		if (row<1 ||row>3){
		    System.out.println("enter a valid row number");
		    continue;}
		 if(colum<1||colum>3){
		      System.out.println("enter a valid colum number");
		      continue;} 
		      row=row-1;
		      colum=colum-1;
		      if(arr[row][colum]!='-'){
		      System.out.println("the box is not empty");
		      continue;}
		      arr[row][colum]=turn;
		      if(arr[0][0]== turn && arr[0][1]==turn && arr[0][2]==turn){
		        System.out.println("the winner is "+turn);  
		        break;
		      }
		      else if (arr[1][0]==turn && arr[1][1]==turn && arr[1][2]== turn){
		          System.out.println("the winner is"+turn);
		          break;
		      
		      }
		      else if (arr[2][0]==turn && arr[2][1]==turn && arr[2][2]==turn ){
		      System.out.println("the winner is"+turn);
		      break;
		      }
		        else if (arr[0][0]==turn && arr[1][0]==turn && arr[2][0]==turn ){
		      System.out.println("the winner is"+turn);
		      break;
		      }
		        else if (arr[0][1]==turn && arr[1][1]==turn && arr[2][1]==turn ){
		      System.out.println("the winner is"+turn);
		      break;
		      }
		        else if (arr[0][2]==turn && arr[1][2]==turn && arr[2][2]==turn ){
		      System.out.println("the winner is"+turn);
		      break;
		      }
		        else if (arr[0][0]==turn && arr[1][1]==turn && arr[2][2]==turn ){
		      System.out.println("the winner is"+turn);
		      break;
		      }
		        else if (arr[0][2]==turn && arr[1][1]==turn && arr[2][0]==turn ){
		      System.out.println("the winner is"+turn);
		      break;
		      }
            boolean draw= false;
		          for(int i=0;i< arr.length;i++){
		for(int j=0;j<arr.length;j++){
                  if(arr[i][j]=='-'){
                      draw=true;
                      break;
                  }
		}	     
		}
		if (draw==false ){
		    System.out.println("the game is a draw");
		    break;
		}
		      if(turn=='X')
		      turn='0';
		      else 
		      turn ='X';
		      
		      
    

		 
		

	
}
    for(int i=0;i< arr.length;i++){
		for(int j=0;j<arr.length;j++){
                   System.out.print(arr[i][j]+" ");
		     
		}
}	}
	}

