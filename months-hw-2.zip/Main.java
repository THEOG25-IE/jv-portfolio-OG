/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		System.out.println("the month is ");
	int nummonth=4;
if(nummonth==1 || nummonth==3 || nummonth==5 || nummonth==7 || nummonth==8 || nummonth==10 || nummonth==12)
{
System.out.println("31 days");
}
else if(nummonth==2)
{
System.out.println("28 days");
}	

    else if (nummonth==4 || nummonth==6 || nummonth==9 || nummonth==11)
    { 
        System.out.println("30 days long");
}
	}
}
