public class InvoiceItem 
{
    String id ;
    String desc;
    int qty ;
    double unitprice;

  public InvoiceItem (String i,String d,int q,double u)
  {
     id=i;
     desc=d;
     qty=q;
     unitprice=u;
  }
 public String getId(){
    return id ;
} 

public String getdesc(){
    return desc ;
} 
public int getQty(){
    return qty;

}
public void setQty(int q){
    qty=q ;
}

  
  
  
  
  
  
  
  
}