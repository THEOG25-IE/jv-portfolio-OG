import java.util.*;
public class Pizza
{
    String Size;
    int Cheesetoppings ;
    int Peperonitoppings ;
    int Hamtoppings ;
    
    public Pizza()//default constructor
{
Size="small";
Cheesetoppings=5;
Peperonitoppings=3;
Hamtoppings=2;
}
public Pizza(String s) //parameterised constructor
{
Size = s;
Cheesetoppings=5;
Hamtoppings=3;
Peperonitoppings=2;
}
public Pizza(  String s,int c) //parameterised constructor
{
Size = s;
Cheesetoppings=c;
Hamtoppings=3;
Peperonitoppings=2;
}
public Pizza(   String s,int c,int h,int p) //parameterised constructor
{
Size = "small";
Cheesetoppings=5;
Hamtoppings=h;
Peperonitoppings=p;
}

    public int calcCost ()
    {
    if (Size.equals("small"))
    return 10+2*(Cheesetoppings+Hamtoppings+Peperonitoppings);
     if (Size.equals("medium"))
    return 12+2*(Cheesetoppings+Hamtoppings+Peperonitoppings);
     if (Size.equals("large"))
    return 14+2*(Cheesetoppings+Hamtoppings+Peperonitoppings);
    return 0;
    }
    public void display()
    {
        System.out.println("Size: "+Size+"\nCheesetoppings:"+Cheesetoppings+"Peperonitoppings: "+Peperonitoppings+"\nHamtoppings:"+Hamtoppings);
    }
  
    public void setSize(String s){
        Size=s;
     }
     public String getSize(){
         return Size ;
     }  
     public  void setCheesetoppings(int c){
        Cheesetoppings=c;
     }
     public int getCheesetoppings(){
         return Cheesetoppings ;
     }
     public  void setHamtoppings(int h){
        Hamtoppings=h;
     }
     public int getHamtoppings(){
         return Hamtoppings ;
     }
       public  void setPeperonitoppings(int p){
        Peperonitoppings=p;
     }
     public int getPeperonitoppings(){
         return Peperonitoppings ;
     }   
     }
     
    



