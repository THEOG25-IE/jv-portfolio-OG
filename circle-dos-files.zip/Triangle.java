import java.util.*;
public class Triangle
{
    int side1;
    int side2;
    int side3;
    float radius;
public Employe1(int s,int s,int s,float r  )
{
side1=s;
side2=s;
side3=s;
radius=r;
}


    
 public double area()
    {
        return radius*3.14*radius;
    }
    public double perimeter()
    {
        return 2*(3.14* radius);
    }
    public String setSide1(int s){
        side1=s;
     }
     public String getSide1(){
         return side1 ;
     }  
       public String setSide2(int s){
         side2=s;
     }
     public String getSide2(){
         return side2 ;
     }
     public  void setSide3(int s){
         side3=s;
     }
     public int getSide3(){
         return side3 ;
     }
    }