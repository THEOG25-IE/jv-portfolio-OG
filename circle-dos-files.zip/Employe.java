import java.util.*;




public class Employe
{
    String Employename;
    int Employesalary;
    
    public void anualsalary()
    {
     int ans=Employesalary*12;
    System.out.println("the anual salary is :"+ans);
    }
  
    public void setEmployename(String e){
         Employename=e;
     }
     public String getEmployename(){
         return Employename ;
     }  
     public  void setEmployesalary(int e){
         Employesalary=e;
     }
     public int getEmployesalary(){
         return Employesalary ;
     }
    }



