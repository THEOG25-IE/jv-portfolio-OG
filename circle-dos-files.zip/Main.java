/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


public class Main 
{
  public static void main (String[] args) {
      /* code */
      /*Pizza obj =new Pizza();
      obj.setSize("small");
      obj.setCheesetoppings (5);
      obj.setPeperonitoppings (2);
      obj.setHamtoppings (3);
      System.out.println(obj.calcCost());
      */
    Date obj= new Date(9,2023,5);
    System.out.println(obj);
    obj.setMonth(5);
    obj.setDay(9);
    obj.setYear(2002);
   System.out.println(obj);
    System.out.println(obj);
   
  }
}