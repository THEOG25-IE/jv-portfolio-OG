import java.util.*;
public class Employe1
{
    int id;
    
    String firstName;
      String lastName;
    int salary;
    public Employe1()//default constructor
{
id=2363211;
firstName="bob";
lastName="sears";
salary=6000;
}
public Employe1(int i,String f,String l,int s) //parameterised constructor
{
id=i;
firstName=f;
lastName=l;
salary=s;
}


    
    public int getAnnualSalary()
    {
     int ans=salary*12;
      return ans;
    }
  
    public String setFirstName(String f){
         firstName=f;
     }
     public String getFirstName(){
         return firstName ;
     }  
       public String setLastName(String l){
         lastName=f;
     }
     public String getLastName(){
         return lastName ;
     }
     public  void setSalary(int s){
         salary=s;
     }
     public int getSalary(){
         return salary ;
     }
    }