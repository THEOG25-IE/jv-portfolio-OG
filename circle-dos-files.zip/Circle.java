import java.util.*;
public class Circle
{
    float radius;
    String color;
    
    public void accept()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter radius  of circle:");
        radius=sc.nextFloat();
        System.out.println("Enter color of circle:");
        color=sc.next();
    }
    public void display()
    {
        System.out.println("radius: "+radius+"\nColor:"+color);
    }
    public double area()
    {
        return radius*3.14*radius;
    }
    public double perimeter()
    {
        return 2*(3.14* radius);
    }
     public void setRadius(float r){
         radius=r;
        
     }
     public String getColor(){
         return color ;
     }  
     public void setColor(String c){
         color=c;
     }
     public float getRadius(){
         return radius ;
     }
    }

