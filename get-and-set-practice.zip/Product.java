import java.util.*;
public class Product{
    
     String productname;
     int productprice;
     String productdescription;
     
     public Product(String n, int p, String d){
     productname=n;
     productprice=p;
     productdescription=d;
     }
      public String getProductName(){
         return productname;
      }
      public int getProductPrice(){
          return productprice;
      }
      public String getProductDescritpion(){
          return productdescription;
      }
      public void setProductPrice(int p){
          productprice=p;
      }
      public String toString (){
        return productname+" "+productdescription+" "+productprice; 
      }
}