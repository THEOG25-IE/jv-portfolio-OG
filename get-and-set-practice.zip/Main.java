/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	Scanner sc=new Scanner(System.in);
	private Arraylist<Product>products;
	private Arraylist<Service>services;
	private Arraylist<Customer>customers;
	private Arraylist<Membership>memberships;


	public static void main(String[] args) {
		Main objj=new Main();
		objj.Displaymenu();
		Scanner scc=new Scanner(System.in);
		System.out.println("Enter your perefered command");
		int ch=scc.nextInt();
		while(ch!=18) {
			if(ch==1) {
				objj.Addproduct();
				System.out.println("Product added sucessfully congratulations!!");
			}
			else if (ch==2) {
				objj.Addservice();
				System.out.println("Service added sucessfully congratulations!!");
			}
			else if(ch==3) {
				objj.Addcustomer();
				System.out.println("Customer added sucessfully congratulations!!");
			}
			else if(ch==4) {
				objj.Addmembership();
				System.out.println("membership added sucessfully congratulations!!");
			}
			else if(ch==5){
			    objj.Viewservices();
			}
			else if(ch==6){
			    objj.Viewproducts();
			}
			else if(ch==7){
			    objj.Viewmemberships();
			}
			else if(ch==8){
			    objj.Viewcustomers();
			}
			else if(ch==9){
			 Product p= objj.searchProducts();
			 if(p==null){
			     System.out.println("Product not found.");
			 }
			 else{
			     System.out.println("Product found");
			 }
			 
			    
			}
				else if(ch==10){
			 Service s= objj.searchServices();
			 if(s==null){
			     System.out.println("Service not found.");
			 }
			 else{
			     System.out.println("Service found");
			 }
				    
				}
				else if(ch==11){
				    objj.removeServices();
				}
				else if(ch==12){
				    objj.removeProducts();
				}
			System.out.println("Enter your perefered command");
			ch=scc.nextInt();
		}
	


}
public Displaymenu() {
	System.out.println("1.add product");
	System.out.println("2.add service");
	System.out.println("3.add customer");
	System.out.println("4.add membership");
	System.out.println("5.view services");
	System.out.println("6.view products");
	System.out.println("7.view memberships");
	System.out.println("8.view customers");
	System.out.println("9.search product");
	System.out.println("10.search service");
	System.out.println("11.remove service");
    System.out.println("12.remove product");
	System.out.println("13.uptade product price");
	System.out.println("14.uptade service price");
	System.out.println("15.uptade membership");
	System.out.println("16.uptade customer deatils");
	System.out.println("17.generate invoice");
	System.out.println("18.view invoice");
	System.out.println("19.exit");

}
public void Addproduct() {
	System.out.println("Write a name for a product");
	String p=sc.nextLine();
	System.out.prinln("sort out a price for a product");
	int pp=sc.nextInt();
	System.out.println("Write a brief description about the product");
	String pd=sc.nextLine();
	Product obj=new Product(p,pp,pd);
	products.add(obj);


}
public void Addservice() {
	System.out.println("Write a name for the service");
	String s=sc.nextLine();
	System.out.println("Sort out a price for the service");
	int sp=sc.nextInt();
	System.out.println("Write a brief description for the service");
	String sd=sc.nextLine();
	Service objs=new Service(s,sp,sd);
	services.add(objs);
}
public void Addcustomer() {
	System.out.println("State your name please");
	String cn=sc.nextLine();
	System.out.println("Write your contact info");
	int cc=sc.nextInt();
	System.out.println("Write your email id");
	String ce=sc.nextLine();
	System.out.println("State you")
	Customer objc=new Customer(cn,cc,ce)
	customers.add(objc);
}
public void AddMembership() {
	System.out.println("name your membership type");
	String sm=sc.nextLine();
	System.out.println("Enter your discount for product");
	String br=sc.nextLine();
	System.out.println("Enter your service discount");
	String si=sc.nextLine();
	Membership objm=new Membershiptype(sm,br,si)
	memberships.add(objm);
}
public void Viewproducts() {
	for(int i=0; i<products.size(); i++) {
		System.out.println(products.get(i));
	}
}
public void Viewservices() {
	for(int i=0; i<services.size(); i++) {
		System.out.println(services.get(i));
	}
}
public void Viewcustomers() {
	for(int i=0; i<customers.size(); i++) {
		System.out.println(customers.get(i));
	}

}
public void Viewmemberships() {
	for(int i=0; i<memberships.size(); i++) {
		System.out.println(memberships.get(i));
	}
 

}
public Product searchProducts(){
    System.out.println("Write the name of the product");
    String np=sc.nextLine();
    for(int i=0;i<products.size();i++){
        if(products.get(i).getProductName().equals(np)){
        return products.get(i);
        }
    }
    return null;
}
public Service searchServices(){
    System.out.println("Write the name of the service");
    String ns=sc.nextLine();
    for(int i=0;i<services.size();i++){
        if(services.get(i).getServiceName().equals(ns)){
        return services.get(i);
        }
    }
    return null;
}
public void removeServices(){
    System.out.println("Point out the name of the service");
    String rs=sc.nextLine();
    for(int i=0;i<services.size();i++){
        if(services.get(i).getServicename().equals(rs)){
            services.remove(i);
            System.out.println("Deleted sucessfully!");
            break;
        }
        
        
    }
}
public void removeProducts(){
    System.out.println("Point out the name of the product");
    String ps=sc.nextLine();
    for(int i=0;i<products.size();i++){
        if(products.get(i).getProductname().equals(ps)){
            product.remove(i);
            System.out.println("Deleted sucessfully!");
            break;

}
        
    }
    
}
public void uptadeProductsprice(){
    System.out.println("State the new price of the product");
    int upp=sc.nextInt();
    System.out.println("State the name of the product");
    String upn=sc.nextLine();
    for(int i=0;i<product.size();i++){
        if(products.get(i).getProductname().equals(upn)){
            products.get(i).setProductPrice(upp);
            System.out.println("Price uptaded sucessfully");
        }
    }
}
public void uptadeServicesprice(){
    System.out.println("State the new price of the service");
    int usp=sc.nextInt();
    System.out.println("State the name of the service");
    String usn=sc.nextLine();
    for(int i=0;i<service.size();i++){
        if(services.get(i).getServicename().equals(usn)){
            services.get(i).setServicePrice(usp);
            System.out.println("Price uptaded sucessfully");
        }
    }
}
public void uptadeMemberships(){
    System.out.println("State the name of the memberships");
    String nm=sc.nextLine();
    System.out.println("Please state the new product discount");
    int prd=sc.nextInt();
    System.out.println("Please state the new service discount");
    int srd=sc.nextInt();
    for(int i=0;i<memberships.size();i++){
        if(memberships.get(i).getMemberName().equals(nm)){
            memberships.get(i).setProductDisc(prd);
            memberships.get(i).setServiceDisc(srd);
        }
    }
}
public void uptadeCustomerDetails(){
    System.out.println("Which of the following you would like to change\n1.Contact\n2.Email\n3.Membershiptype");
    int upi=sc.nextInt();
    System.out.println("State your name please");
    String ccn=sc.nextLine();
    for(int i-0;i<customers.size();i++){
        if(customers.get(i).getCName().equals(ccn)){
            if(upi==1){
                System.out.println("Enter your new contact name");
                String ncn=sc.nextLine();
                customers.get(i).setCcontact(ncn);
            }
            
        }
    }
}
    
}
