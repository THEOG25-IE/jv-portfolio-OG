   import java.util.*;
public class Membership{
    String membername;
    int productdisc;
    int servicedisc;
    
    public Membership(String mn , int pd, int sd){
        membername=mn;
        productdisc=pd;
        servicedisc=sd;
    }
    public String getMemberName(){
        return membername;
    }
    public int getProductDisc(){
        return productdisc;
    }
    public int getServiceDisc(){
        return servicedisc;
    }
    public void setProductDisc(int pd){
        productdisc=pd;
    }
    public void setServiceDisc(int sd){
        servicedisc=sd;
    }
    public String toString(){
        return membername+" "+productdisc+" "+servicedisc;
    }
}