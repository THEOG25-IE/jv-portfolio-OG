import java.util.*;
public class Invoice {

	private int invoiceid;
	private Customer customer;
	private Arraylist<Product> productsPurchased;
	private Arrylist <Service> servicesTaken;

	public Invoice(int idd, Customer co, ) {
		invoiceid=idd;
		customer=co;
		productsPurchased=new Arraylist();
		servicesTaken=new Arraylist();
	}
	public int getInvoiceid() {
		return invoiceid;
	}
	public void setInvoiceid(int idd) {
		invoiceid=idd;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer co) {
		Customer=co;
	}

	public void addProduct(Product p) {
		productspurchased.add(p);

	}
	public void addService(Service s) {
		servicesTaken.add(s);
	}
	public float CalculateBill() {
		double productotal=0;
		for(int i=0; i<=productsPurchased.size(); i++) {
			producttotal=producttotal+productsPurchased.get(i).getProductPrice();

		}
		double servicetotal=0;
		for(int i=0; i<=servicesTaken.size(); i++) {
			servicestotal=servicetotal+servicesTaken.get(i).getServicePrice();
		}
		servicetotal=servicetotal-customer.getmembershiptype().getServiceDiscount()*servicetotal/100;
		productotal=producttotal-customer.getmembershiptype().getProductiscount()*productotal/100;
		return productotal+servicetotal;
	}


}