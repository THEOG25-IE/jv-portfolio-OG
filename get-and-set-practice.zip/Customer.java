import java.util.*;
public class Customer {

	String cname;
	String cmail;
	String ccontact;
	Membership membershiptype;

	public Customer(String cn, String cm, String cc, Membership mt) {
		cname=cn;
		cmail=cm;
		ccontact=cc;
		membershiptype=mt;
	}
	public Membership getMembershiptype() {
		return membershiptype;
	}
	public String getCname() {
		return cname;
	}
	public String getCmail() {
		return cmail;
	}
	public String getCcontact() {
		return ccontact;
	}
	public void setCmail(String cm) {
		cmail=cm;
	}
	public void setCcontact(String cc) {
		ccontact=cc;
	}
	public void setMembershiptype(Membership mt) {
		membershiptype=mt;
	}
	public String toString() {
		return cname+" "+cmail+" "+ccontact;

	}
}