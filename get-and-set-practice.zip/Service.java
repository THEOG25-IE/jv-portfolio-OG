import java.util.*;
public class Service{
    String servicename;
    int serviceprice;
    String servicedescription;
    public Service(String sn, int sp, String sd){
        servicename=sn;
        serviceprice=sp;
        servicedescription=sd;
    }
    public String getServiceName(){
        return servicename;
    }
    public int getServicePrice(){
        return serviceprice;
    }
    public String getServiceDescription(){
        return servicedescription;
    }
    
    public void setServicePrice(int sp){
        serviceprice=sp;
    }
    public String toString(){
        return servicename+" "+servicedescription+" "+serviceprice;
    }
    
}


