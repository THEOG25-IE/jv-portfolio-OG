import java.util.*;
public class Date
{
    int day;
    int month;
    int year;

public Date (int d,int m,int y)
{
    day=d;
    month=m;
    year=y;
}

public void setDay(int d){
    if(month==1 ||month==3||month==5||month==7||month==8||month==10||month==12){
     if(d>=1&&d<=31) 
     day=d;
     else{
         System.out.println("invalid");
     }
    }
    else if(month==2){
        if(d>=1&&d<=28)
        day=d;
        else{
            System.out.println("invalid");
        }
    }
    else if(month==4||month==6||month==9||month==11){
        if(d>=1&&d<=30)
        day=d;
        else{
            System.out.println("invalid");
        }
        
    }
    day=d;
}
public int getDay(){
    return day ;
}
public void setMonth(int m){
    if(m>=1&&m<=12)
    month=m;
    else {
        System.out.println("invalid");
    }
    
}
public int getMonth(){
    return month;
}
public void setYear(int y){
    year=y;
}
public int getYear(){
    return year;
}
public String toString(){
    return day+"/"+month+"/"+year+"/";
}
}
