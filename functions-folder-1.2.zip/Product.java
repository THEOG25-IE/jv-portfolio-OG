import java.util.*;
 public class  Product{


private int productid;

private String productname;

private int quantity;

private double price ;

public Product(int i,String n,int q,double p){

productid=i;
productname=n;
quantity=q;
price=p;

}

 public int getProductid(){

return productid;


}

public String getProductname(){

return productname;

}



 public int getQuantity(){
    return quantity;


}


public void setQuantity (int q) {
    quantity=q;

}

public double gePrice(){
    return price;

} public void setPrice (double p) {
    price=p;

}
public String toString(){
    return productid+","+productname+","+quantity+","+price;
}
}