import java.util.*;
public class Account 
{
 String id; 
 String name;
 int balance;
  
  public Account(){
      id="6590643";
      name="leonardo";
      balance=100000000;
  }
    
   public Account (String i,String n,int b){
       id=i;
       name=n;
       balance=b;
   } 
    
    public String getId(){
        return id;
    }
    
  public String getName(){
        return name;
    }
    public int getBalance(){
        return balance;
    }
    public int credit (int a){
        balance=a+balance;
        return balance;
    }
    public int debit (int d){
        if (balance<d)
            System.out.println("insuficent funds");
        else{
            balance =balance-d;
            
        }
        return balance;
    }
   public String toString(){
       return "account  "+id+",account"+name+",account"+balance;
   }
   public int transfer(Account obj, int amount ){
     if (balance<amount)
            System.out.println("insuficent funds");
       else{
            balance =balance-amount;
            obj.credit(amount);
            
        }
        return balance;     
   }
}