/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		/*System.out.println("Hello World");
	Account obj=new Account("13546674","dylan",1000);
	System.out.println(obj.getBalance());*/
	/*Date obj= new Date(1,6,2001);
	System.out.println(obj);
	obj.setDay(31);
	obj.setMonth(6);
	obj.setYear(2008);
	System.out.println(obj.getDay());
	System.out.println(obj.getMonth());
	System.out.println(obj.getYear());*/
	Product obj= new Product(0001,"sharpener",5000,0.29);
	
	Product obs= new Product(0002,"pencil",6001,0.99);
	
    Product obh= new Product(0003,"book",6009,1.99);
    
    Shop    obg= new Shop ("backoescl",obj,obs,obh );
    
    System.out.println(obg.getTotalquantity());
    obg.restock();
   
	}
}

