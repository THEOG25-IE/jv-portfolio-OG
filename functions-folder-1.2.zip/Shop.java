import java.util.*;
public class Shop{
String Shopname;
Product producta;
Product productb;
Product productc;
public Shop (String s,Product a,Product b,Product c ){
Shopname=s;
producta=a;
productb=b;
productc=c;
}
public String getShopname(){
    return Shopname;
}
public Product getProducta(){
    return producta;
}
public Product getProductb(){
    return productb;
}public Product getProductc(){
    return productc;
}
public int getTotalquantity(){
    
   return producta.getQuantity()+ productb.getQuantity()+ productc.getQuantity();
       
    
}
public void restock(){
    if(producta.getQuantity()<10)
    System.out.println(producta);
     if(productb.getQuantity()<10)
    System.out.println(productb);
     if(productc.getQuantity()<10)
    System.out.println(productc);
}

    

}