
 import java.util.*;
public class Department
{
String name;
String location;
int numberofemployees;
public Department(String n,String l,int e ){
name=n;
location=l;
numberofemployees=e;
}
public String getName(){
return name;}
public String getLocation(){
return location;}
public void setlocation(String l){
location=l;}
public int getNumberofemployes(){
return numberofemployees;}
public String toastring(){
return name+","+location+","+numberofemployees;
}
}

