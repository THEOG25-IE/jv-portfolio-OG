import java.util.*;
 public class Employe{


private int empid;

private String empname;

private double empsalary;

private Department dpt;

public Employe (int i, String n,double e,Department d){

empid=i;

empname=n;

empsalary=e;

dpt=d;

}

 public int getEmpid(){

return empid;


}

public String getEmpname(){

return empname;

}



public void setEmpname (String n) {
    empname=n;

} public double getEmpsalary(){
    return empsalary;


}


public void setEmpsalary (double s) {
    empsalary=s;

}

public Department getDpt(){
    return dpt;

} public void setDpt (Department d) {
    dpt=d;

}
public String getDepatmentname(){
    return dpt.getName();
}
}