public class MovablePoint implements Movable
{
    private int x;
    private int y;
    private int xSpeed;
    private int ySpeed;
    
   public MovablePoint(int x,int y,int xSpeed ,int xy){
    
    }
    
    }
    