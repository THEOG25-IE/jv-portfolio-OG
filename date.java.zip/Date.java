import.java.util.*;
public class Date 
{
    int day;
    int month;
    int year;
    
    public  Date (int d,int m,int y)
    {
        day=d;
        month=m;
        year=y;
    }
    public Date (){
        day=19;
        month=7;
        year=2002;
    }
public void setDay(int d){
    if(month==1||month==3||month==5||month==7||month==8||month==10||month==12){
   if(d>=1&&d<=31)
   day=d;
   else{
       System.out.println("invalid");
   }
    }
}    
    
}