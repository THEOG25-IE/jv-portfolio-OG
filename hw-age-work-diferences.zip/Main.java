/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		int age=26;
		char gender='M';
		if (gender=='F'){
		System.out.println("she will work at urban areas");}
	else if (gender=='M'){
	    if (age>=20 && age<=40)
	    System.out.println("can work everywhere");
	    if(age>=41 && age<=60)
	    System.out.println("he will work at urban areas");
	    
	    
	    
	    
	} else
	 System.out.println("error");




	}
}
