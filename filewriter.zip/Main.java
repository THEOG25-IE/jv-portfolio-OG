/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
import java.io.*;
public class Main
{
    public void playquiz()throws IOException{
        FileReader fr=new FileReader("data.txt");
        Scanner sr=new Scanner(fr);
        int score=0;
        while(sr.hasNext()){
            String s=sr.nextLine();
            String arr[]=s.split(":");
            System.out.println(arr[0]);
            System.out.println("1."+arr[1]);
            System.out.println("2."+arr[2]);
            System.out.println("3."+arr[3]);
            System.out.println("4."+arr[4]);
            Scanner sd=new Scanner (System.in);
            System.out.print("Choose the correct answer 1,2,3 or 4 ");
            int answer=sd.nextInt();
            int correctanswer=Integer.parseInt(arr[5].trim());
            if(correctanswer==answer)
              score+=1;
              
        }
        System.out.println("this is your score: "+score);
    }
    public void makequiz()throws IOException{
String stop="no";
FileWriter fw=new FileWriter ("data.txt",true);
Scanner sc=new Scanner(System.in);
while(stop.equals("no")){
    System.out.println("enter a question");
    String question=sc.nextLine();  
    System.out.println("enter the first option");
    String option1=sc.nextLine();
    System.out.println("enter the second option");
    String option2=sc.nextLine();
    System.out.println("enter the third option");
    String option3=sc.nextLine();
    System.out.println("enter the fourth option");
     String option4=sc.nextLine();
    System.out.println("enter the correct answer(1,2,3,4)");
     int correctoption =sc.nextInt();
     fw.write(question+":"+option1+":"+option2+":"+option3+":"+option4+":"+correctoption+"\n");
     System.out.println("do you wish to stop");
      stop=sc.nextLine();
}
  
    fw.close();
   
}
public static void main (String[]args)throws IOException{
    Main obj=new Main();
    Scanner scr=new Scanner(System.in);
    System.out.println("What do you want to do in this situation");
    System.out.println("1.Add questions to your liking");
    System.out.println("2.play the quiz");
     System.out.println("3.Exit");
    int choice=scr.nextInt();
    while(choice!=3){
        
    
    if(choice==1)
     obj.makequiz();
     else if(choice==2)
     obj.playquiz();
     else
     System.out.println("invalid choice");
     System.out.println("What do you want to do in this situation");
    System.out.println("1.Add questions to your liking");
    System.out.println("2.play the quiz");
    System.out.println("3.Exit");
      choice=scr.nextInt();   
    }
     
}
}
