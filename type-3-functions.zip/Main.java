/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java .util.*;
public class Main
{
    public boolean returnfalse()
    {
    Scanner sc= new Scanner(System.in);
   System.out.println("enter 2 numbers");
   int num1=sc.nextInt();
    int num2=sc.nextInt();
    int ans=num1+num2;
   if (ans==10||num1==10||num2==10)
   return true;
   else
   return false;
    
	 
		
	}
	public static void main(String[] args){
	
	Main m=new Main();
	 boolean result=m.returnfalse();
	 System.out.println("the result is:"+result);
	}
	
}
