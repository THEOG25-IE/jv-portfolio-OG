/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Type 4: functions which does accept parameters and return value
import java.util.*;
public class Main
{
public int addition(int num1, int num2)
{

int sum=num1+num2;
return ans;
}
public static void main(String[] args) {

Main m=new Main();
Scanner sc=new Scanner(System.in);
System.out.println("Enter 2 numbers:");
int a=sc.nextInt();
int b=sc.nextInt();
result=m.addition(a,b);
System.out.println("The total is "+result);
}
}