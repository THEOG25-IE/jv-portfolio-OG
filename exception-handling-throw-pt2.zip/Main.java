/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		try{
		    Scanner sc=new Scanner(System.in);
		    System.out.println("Enter your age:");
		    int age=sc.nextInt();
		    if(age<0){
		         AgeException ae=new AgeException("Invalid Age");
		        throw ae;  
		        
		    }
		    if(age<18){
		        AgeException ae=new AgeException("ONLY FOR 18+");
		        throw ae;  
		        
		    }
		        
		}
		
		catch(InputMismatchException ie){
		    System.out.println("Enter only numbers:");
		}
		catch(AgeException ae){
		    ae.display();
		}
	}
}
