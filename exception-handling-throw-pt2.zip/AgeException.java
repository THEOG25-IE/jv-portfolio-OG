public class AgeException extends Exception
{
    private String message;
    public AgeException(String message)
    {
        super();
        this.message=message;
    }
    public void display(){
       System.out.println(message);
    }
}