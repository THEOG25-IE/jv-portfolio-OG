/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


import java.util.Scanner; 

public class Main {
   public static void main(String[] args) { 
      Scanner scanner = new Scanner(System.in); 
      System.out.print("Enter the temperature for the day (enter 0 to quit):"); 
      double max = 0 ;
      double temp= scanner.nextDouble(); 
      while(temp !=0) {
         System.out.print("Enter the temperature for the day (enter 0 to quit):"); 
         temp = scanner.nextDouble(); 
        
         if(temp > max) {
            max = temp; 
         }
      }
      System.out.println("Max temperature of all values entered is: " + max);
   }
}