/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main {

public static void main( String [] args){
    Scanner sc = new Scanner(System.in);
 System.out.println("enter a number");
 int num= sc.nextInt();
 int count = 0;
 while(num != 0){
     int remainder =num % 10 ;
     count=count + 1 ;
     num/=10;
    
 }System.out.println(count);
}
}