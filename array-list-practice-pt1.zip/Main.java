/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc= new Scanner(System.in);
	    System.out.println("Enter a word");
	   String s=sc.next();
	   	ArrayList<String> words = new ArrayList();
	   	 int count=0;
	  while(s.equals("stop")==false)
	  {
	     count=count+1;
	     words.add(s);
	  System.out.println("Enter a word");
	   s=sc.next();
	  }
	  System.out.println("This how words were typed"+" "+count);
	    
	}
}
