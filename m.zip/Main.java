/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		int five =5; 
		for(five=1;five<=5;five++){
		int counter;
		int factorial=1;
		for(counter=1;counter<=five;counter++){
		    factorial=factorial*counter;
		    
		    
		}System.out.println(factorial);
		    
		}
	}
}
