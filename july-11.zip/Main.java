/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		    Scanner scanner=new Scanner(System.in);
		    System.out.println("please enter the cost price");
		    float cp =scanner.nextFloat{};
		    System.out.println("please enter the selling price");
		     float sp=  scanner.nextFloat{};
		    if(cp>sp ){     
		      System .out.println("a loss of"+(cp-sp));
		      float loss=cp-sp;
		      float x=loss/cp*100 ;
		      
		    }
		    else{
		       System .out.println("a profit  of"+(sp-cp));
		      float profit=sp-cp;
		      float x= profit/cp*100;
		    }
	}
}
