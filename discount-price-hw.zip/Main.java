/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		int quantity=3700;
		int price=134;
		double discount=0f;
	double total=0f;
		if(quantity>1000 ){
		 discount=quantity*price*0.1;
		total=(price*quantity)-discount;
		
		}
	else
	total=price*quantity;	
	System.out.println(total);
		System.out.println(discount);
	} 
}
