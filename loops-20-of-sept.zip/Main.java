/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.
1/5 +2/4+3/3+4/2+5/1

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
			int numerator;
		int denominator ;
		float total=0f;
		for(numerator=1,denominator=5; numerator<=5;  numerator+=1, denominator+=-1 ){
		    total=total+(float)numerator/(float)denominator;
		}
		
			System.out.println(total);
	}
}
