/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		int arr[][]=new int[2][3];
		Scanner scanner= new Scanner(System.in);
		for(int i=0;i<arr.length;i++) //first loop represents how many rows are Length represents number of
{
for (int j=0;j<arr[0].length; j++) //arr[0].length represents number of columns in each row.
{

System.out.println("Enter value for row "+i+" and colum  "+j);

 arr[i][j]=scanner.nextInt();
}
    
}
for (int i=0;i< arr.length;i++){ 
//first loop represents how many rows, arr length represents number of roas
for(int j=0;j<arr[0].length; j++){ //ar[0].length represents number of columns in each row.
System.out.print(arr[i ][j]+" ");
}
 System.out.println("");   
}
	}
}
