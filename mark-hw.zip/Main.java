/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

		
public class Main
{
public static void main(String[] args) {
int mark=14;
if(mark<=20 && mark>=17)
{
System.out.println("Excellent");
}
else if(mark>=14 && mark<=16 )

{
System.out.println("Good");

}


 else if(mark>=10  && mark<=13 )
 {
 System.out.println("Average");  
 }
 else if(mark>=5  && mark<=9)
 {
  System.out.println("Satisfactory ");
 }
 else if(mark<=5 )
 
{
System.out.println("poor performance");
}
}
	}

