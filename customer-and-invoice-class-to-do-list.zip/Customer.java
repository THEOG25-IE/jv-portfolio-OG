import java.util.*;
public class Customer
{
    int id;
    String name;
    int discount;
    
    
public Customer(int id,String name,int discount){
    id=i;
    name=n;
    discount=d;
}
public void setDiscount(int d){
    discount=d;
}
public int getId(){
    return id; 
}
public String getName(){
    return name; 
}public int getDicount(){
    return discount; 
}

public String toString(){
    return  name " "+id " "+discount;
}
}
