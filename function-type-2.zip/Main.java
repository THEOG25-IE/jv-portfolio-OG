/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Type 2: functions which accept parameters but dont return value
import java.util.*;
public class Main
{
public void addition(int a, int b)//formal parameters
{
int sum=a+b;
System.out.println("The total is:"+ans);
}
public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.println("Enter 2 numbers:");
int num1=sc.nextInt();
int num2=sc.nextInt();
Main m=new Main();
m.addition(num1, num2);//actual parameters

}
}