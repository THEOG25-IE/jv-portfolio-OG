public class Cylinder extends Circle 
{
private double height;  
    


public Cylinder(){
    super();
    height=0.0;
    
    
}    
public Cylinder(String color,double h, double radius){
    super(radius,color);
    height=h;
}
  
  public double getHeight(){
      return height;
  }
  public void setHeight(double h){
      height=h;
  }
  public double getVolume(){
      double volume=getArea()*height;
      return volume;
  }
}