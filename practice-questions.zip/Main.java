/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    boolean answer=divisibleby10(5,4);
	    System.out.println("The Answer is "+answer);
	  double result=absolute(160);
	  System.out.println("The result is "+result);
	  int gift=freecup(200);
	  System.out.println("Wow youre extra number of Free cups is "+gift);
	  boolean kn=kkk(66,67);
	  System.out.println("This is answr to youre inquire."+kn);
	}
		public static double absolute(double num){
		    if(num<0){
		        num=num*-1;
		    }
		    return num;
		    
		}
		public static boolean divisibleby10(int a , int b){
		    int total=a+b;
		    if(a==10||b==10||total==10 ){
		        return true;
		    }
		    else
		    {
		        return false;
		    }
		    
		}
		public static int freecup(int numc){
		    numc=numc/6;
		    return numc+numc;
		}
		public static boolean kkk(int k,int n){
		   if(Math.pow(k,k)==n){
		       return true;
		   } 
		   else{
		       return false;
		   }
		   
		}
	
}
