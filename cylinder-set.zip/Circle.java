public class Circle{
    
     private double radius;
    
    public Circle(){
        radius=0;
    }
    public Circle(double r){
        radius=r;
        
    }
    public void setRadius(double r){
        radius=r;
    }
    public double getRadius(){
        return radius;
    }
    public double  getArea(){
        double area=3.14*radius*radius;
        return area;
    }
    public String toString(){
        return "radius="+radius;
    }
}