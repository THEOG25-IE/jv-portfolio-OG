public class Cylinder extends Circle
{
     private int height ;
    
    
public Cylinder(){
    super();
height=0;

}    
   public Cylinder(int h,double r ){
       super(r);
       height=h;
      
   }
   public void setHeight(int h){
       height=h;
   }
   public int getHeight(){
       return height;
   }
  
 
   public double calcvlmn(){
       return getArea()*height;
   }
  public String toString(){
     return "height="+height+super.toString();
  }
   }
