/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		int year=2024;
		if(year%4==0){ if (year%100==0 && year%400!=0 ){
		System.out.println(" not leap year");
		 }else {
		
			System.out.println("leap year");
			
		    
		
		 }
	} else 
	System.out.println("not a leap year");
		
	}
}

