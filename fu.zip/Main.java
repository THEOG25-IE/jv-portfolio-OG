/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java .util.*;
public class Main
{
    public void printdigits(){
    Scanner sc=new Scanner(System.in);
    System.out.println("enter a number");
    int num=sc.nextInt();
while(num>0){
  System.out.println(num % 10);
  num=num/10;
}
}
    public static void main(String[]args){
      Main obj=new Main();
        obj.printdigits();
    }
 
	
	
}
