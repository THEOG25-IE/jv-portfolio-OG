/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java. util.*;
public class Main
{
	public void sumoftwo (int a , int b)
	{
    if(a==b){
    a=a+b;
  a=a*2;
    System.out.println("result:"+a);
    }
    else{
      a=a+b;  
      System.out.println("result:"+a);  
    }
	    
	}
	public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	 System.out.println("enter a number");
    int a=sc.nextInt();
     System.out.println("enter a number");
    int b=sc.nextInt();
    Main M= new Main();
 M.sumoftwo(a,b);
	}
}
