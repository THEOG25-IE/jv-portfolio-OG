/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
 import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		Scanner sc= new Scanner (System.in);
		System.out.println("enter number of slices");
		int numofslices;
		
		numofslices=sc.nextInt();
		System.out.println("enter Number of people eating");
		int numofpeoeating;
		numofpeoeating=sc.nextInt();
	if(numofslices%numofpeoeating==0){
	System.out.println("its posible");}
	 else{
	 System.out.println("not posible");
	     
	 }
	


		
	}
}
