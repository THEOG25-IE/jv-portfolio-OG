public class MovablePoint extends Point
{
  

private float xSpeed;
   
private float ySpeed;
   

public MovablePoint (float x, float y, float xSpeed, float ySpeed)
  {
	
super (x, y);
	
this.xSpeed = xSpeed;
	
this.ySpeed = ySpeed;
  
} 

public MovablePoint (float xSpeed, float ySpeed)
  {
	
this (0.0f, 0.0f, xSpeed, ySpeed);
  
} 
 
public MovablePoint ()
  {
	
this (0.0f, 0.0f);
  
} 
 
public float getXSpeed ()
  {
	
return xSpeed;
  
}
  
 
public void setXSpeed (float xSpeed)
  {
	
this.xSpeed = xSpeed;
  
} 
 
public float getYSpeed ()
  {
	
return ySpeed;
  
}
  
 
public void setYSpeed (float ySpeed)
  {
	
this.ySpeed = ySpeed;
  
} 
 
public void setLocation (float x, float y)
  {
	
super.setX (x);
	
super.setY (y);
  
} 
 
public float[] getSpeed ()
  {
	
return new float[]
	{
	xSpeed, ySpeed};
  
} 
 
 
public String toString ()
  {
	
return super.toString () + ", xSpeed=" + xSpeed + ", ySpeed=" + ySpeed;
  
}

}


 
