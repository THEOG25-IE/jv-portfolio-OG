public class Member {
	int memberid;
	String name;
	String membershiptype;


	public Member(int i, String n, String m ) {
		memberid=i;
		name=n;
		membershiptype=m;
	}
	public int getMemberid() {
		return memberid;
	}
	public String getName() {
		return name;
	}
	public String getMembershiptype() {
		return membershiptype;
	}
	public void setMembershiptype(String m) {
		membershiptype=m;
	}
}