/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.text.SimpleDateFormat;
import java.util.*;
public class Main
{
	private ArrayList<Book>books;
	private ArrayList<Member>members;
	private ArrayList<Loan>loans;
	private Scanner sc=new Scanner(System.in);
	public Main() {
		books=new ArrayList();
		members=new ArrayList();
		loans=new ArrayList();

	}
	public void displayMenu() {
		System.out.println("1.Add new book");
		System.out.println("2.Add new member");
		System.out.println("3.Remove member");
		System.out.println("4.Update Book Stock");
		System.out.println("5.Search book by name");
		System.out.println("6.Search book by author");
		System.out.println("7.Issue Book");
		System.out.println("8.Return book");
		System.out.println("9.Exit");

	}
	
	public void addNewBook() {
		System.out.println("Enter a new title");
		String t=sc.nextLine();
		System.out.println("Enter a author");
		String a=sc.nextLine();
		System.out.println("Enter a Publicationdate");
		String p=sc.nextLine();
		System.out.println("Enter stock");
		int s=sc.nextInt();
		System.out.println("Enter Isbn number");
		int i=sc.nextInt();
		Book obj=new Book(i,t,a,p,s);
		books.add(obj);
	}
	public void addNewMemberid() {
		System.out.println("Enter a new memberid");
		int mi=sc.nextInt();
		System.out.println("Enter a name");
		String n=sc.nextLine();
		System.out.println("Enter a membershiptype");
		String ms=sc.nextLine();
		Member objs=new Member(mi,n,ms);
		members.add(objs);
	}
	public void removeMember() {
		System.out.println("Enter your member id");
		int mii=sc.nextInt();
		for(int i=0; i<members.size(); i++) {
			if(members.get(i).getMemberid()==(mii)) {
				members.remove(i);
				System.out.println("Member successfully removed ");
				break;
			}
		}
	}
	public void uptadeBookStock() {
		System.out.println("Enter isbn number");
		int is=sc.nextInt();
		int flag=0;
		for(int i=0; i<books.size(); i++) {
			if(books.get(i).getIsbn()==(is)) {
				System.out.println("Enter new book stock");
				int bs=sc.nextInt();
				       books.get(i).setStock(bs);
				       System.out.println("Stock successfully uptadeted");
				       flag=1;
				       break;
			}
		} if(flag==0){
		    System.out.println("Book not found");
		}
	}
	public void searchBookByName(){
	    System.out.println("enter name of your book of choice");
	    String nm=sc.nextLine();
	    int flag=0;
	    for(int i=0;i<books.size();i++){
	        if(books.get(i).getTitle().equals(nm)){
	            System.out.println("Book successfully found");
	            flag=1;
	            break;
	        }
	    }
	    if(flag==0){
	        System.out.println("Book not found");
	    }
	}
	public void searchBookByAuthor(){
	    System.out.println("enter name of your author of choice");
	    String nsm=sc.nextLine();
	    int flag=0;
	    for(int i=0;i<books.size();i++){
	        if(books.get(i).getAuthor().equals(nsm)){
	            System.out.println(books.get(i).getTitle());
	            flag=1;
	           
	        }
	    }
	    if(flag==0){
	        System.out.println("author not found");
	    }
	}
	public void issueBook(){
	    System.out.println("enter your isbn number");
	    int ibn=sc.nextInt();
	    System.out.println("enter your membership id");
	    int mim=sc.nextInt();
	    int randomNumber = (int)(1000 + Math. random( )*((9999-1000+1)));
	    String loanid=ibn+""+mim+""+randomNumber;
	    Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        String issueDate =""+ dateFormat.format(calendar.getTime());
        

        // Add 7 days to the current date
        calendar.add(Calendar.DAY_OF_YEAR, 7);

       String dueDate= ""+dateFormat.format(calendar.getTime());
       Loan obj=new Loan(loanid,issueDate,dueDate,mim,ibn);
	    for (int i=0;i<books.size();i++) {
        if (books.get(i).getIsbn()==(ibn)) {
            if (books.get(i).getStock() > 0) {
                books.get(i).setStock(books.get(i).getStock() - 1);
                System.out.println("Book issued successfully");
                loans.add(obj);
                return;
            } else {
                System.out.println("Book is out of stock");
                return;
            }
        }
    }
    System.out.println("Book with ISBN " + ibn + " not found"); 
	}

	public void returnBook(){
	    System.out.println("Enter your memberid");
	    int msi=sc.nextInt();
	    System.out.println("Enter book isbn");
	    int isb=sc.nextInt();
	    for(int i=0;i<loans.size();i++){
	        if(loans.get(i).getIsbn()==(isb) && loans.get(i).getMemberid()==(msi)){
	          loans.remove(i);
	           System.out.println("Book returned");
	        }
	    }
	    for (int i=0;i<books.size();i++) {
        if (books.get(i).getIsbn()==(isb)) {
            
                books.get(i).setStock(books.get(i).getStock() + 1);
                
            }
            
        }
	    
	    }
	    



	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    Main objs=new Main();
	    objs.displayMenu();
	    System.out.println("Enter your choice");
	    int cho=sc.nextInt();
	    while(cho!=9){
	        if(cho==1){
	            objs.addNewBook();
	        }
	       else if(cho==2){
	           objs.addNewMemberid();
	       }
	       else if(cho==3){
	           objs.removeMember();
	       }
	       else if (cho==4){
	           objs.uptadeBookStock();
	       }
	       
	       else if(cho==5){
	           objs.searchBookByName();
	       }
	       else if(cho==6){
	           objs.searchBookByAuthor(); 
	       }
	       else if(cho==7){
	           objs.issueBook();
	       }
	       else if(cho==8){
	           objs.returnBook();
	       }
	       else if (cho==9){
	         break;                    
	       }
	    }
		System.out.println("Hello World");
	}
}
