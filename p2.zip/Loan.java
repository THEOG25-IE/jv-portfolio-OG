public class Loan{
   String loanid;
    String issuedate;
    String duedate;
    int memberid;
    int isbn;
    public Loan(String l,String i,String d, int m,int s){
        loanid=l;
        issuedate=i;
        duedate=d;
        memberid=m;
        isbn=s;
    }
      public String getLoanid(){
        return loanid;
    }
      public String getIssuedate(){
        return issuedate;
    }
      public String getDuedate(){
        return duedate;
    }
      public void setDuedate(String d){
       duedate=d;
    }
      public int getMemberid(){
        return memberid;
    }
      public int getIsbn(){
        return isbn;
    }
}