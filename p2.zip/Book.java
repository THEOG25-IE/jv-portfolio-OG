public class Book {
	int isbn;
	String title;
	String author;
	String publicationdate;
	int stock;

	public Book(int i,String t,String a,String p,int s ) {
		isbn=i;
		title=t;
		author=a;
		publicationdate=p;
		stock=s;
	}
	public String getTitle() {
		return title;
	}
	public String getAuthor() {
		return author;
	}
	public String getPublicationdate() {
		return publicationdate;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int s) {
		stock+=s;
	}
	public int getIsbn() {
		return isbn;
	}


}