/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number (0 to exit): ");
        float number = sc.nextFloat();
        float sum = 0;
        int count = 0;

        while(number != 0) {
            count++;
            sum += number;
            System.out.println("Enter a number (0 to exit): ");
            number = sc.nextFloat();
        }

        float average = sum/count;
        System.out.println("Average of all values entered is: "+average);
    }
}
